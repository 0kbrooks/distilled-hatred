plugins {
    application
    //id("io.ktor.plugin") version "2.3.12"
}

repositories {
    mavenCentral()
}

dependencies {
    testImplementation("junit:junit:4.13.2")
    implementation("com.google.guava:guava:31.0.1-jre")
}

application {
    mainClass.set("gregtown.Main")
}
tasks.jar {
  manifest {
      attributes["Main-Class"] = "gregtown.Main"
  }
  configurations["compileClasspath"].forEach { file: File ->
      from(zipTree(file.absoluteFile))
  }
}