package gregtown.map;

//import java.util.Hashtable;

public class RegionMapTile extends MapTile {
  private MapTile[] pp = {new MapTile(-1,-1), 
                          new MapTile(-1, 0), 
                          new MapTile(-1, 1), 
                          new MapTile( 0,-1), 
                          new MapTile( 0, 0), 
                          new MapTile( 0, 1), 
                          new MapTile( 1,-1), 
                          new MapTile( 1, 0), 
                          new MapTile( 1, 1)};
  private Map submap = new Map(pp,true);
  public Map submap() {
    return submap;
  }
  public RegionMapTile(int X, int Y, String DESC, char CHAR) {
    super(X, Y, DESC, CHAR);
  }
  public RegionMapTile(int X, int Y, String DESC) {
    super(X, Y, DESC);
  }
  public RegionMapTile(int X, int Y) {
    super(X, Y);
  }
}