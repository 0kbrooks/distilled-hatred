package gregtown.map;

//import java.util.Hashtable;
//import java.math.;
import java.util.function.Supplier;

public class MapTile {
  protected int x;
  protected int y;
  protected String description;
  private Character character;
  private static char[] possibleChars = {'#'/*,'$','%','&'*/};
  protected Supplier<Map> parentMap;
  public MapTile(int X, int Y, String DESC, char CHAR) {
    this.x = X;
    this.y = Y;
    this.description = DESC;
    if(CHAR!='#'){
      this.character = CHAR;
      //character = possibleChars[(int)Math.floor(Math.random()*possibleChars.length)];
    }
  }

  public MapTile(int X, int Y, String DESC) {
    this(X, Y, DESC, '#');
  }
  public MapTile(int X, int Y, char CHAR) {
    this(X, Y, "", CHAR);
  }
  public MapTile(int X, int Y) {
    this(X, Y, "", '#');
  }
  public char character() {
    char out = '#';
    if(character!=null){
      out = character;
    } else {
      if(parentMap!=null){
        if(parentMap.get().map().containsKey(x-1)){
          if(parentMap.get().map().get(x-1).containsKey(y-1)) {
            // estoy agrietado en el coding
            // estoy loqueando adentro
            //out = parentMap.get().map().get(x-1).get(y).character;
          } else {
            out = '[';
          }
        } else {
          out = '_';
        }
      } else {out = possibleChars[(int)Math.floor(Math.random()*possibleChars.length)];}
    }
    return(out);
  }
}