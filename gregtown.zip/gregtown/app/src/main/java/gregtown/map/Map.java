package gregtown.map;

import java.util.Hashtable;
import java.lang.IllegalArgumentException;

public class Map {
  private Hashtable<Integer,Hashtable<Integer,MapTile>> map = new Hashtable<Integer,Hashtable<Integer,MapTile>>();
  private int[] dimensions = {0,0,0,0};
  private boolean forceDimensions = false;
  // min x, min y, max x, max y
  public Hashtable<Integer,Hashtable<Integer,MapTile>> map() {
    return map;
  }
  public int[] dimensions() {
    return dimensions;
  }
  public boolean forceDimensions() {
    return forceDimensions;
  }
  public Map buildMap(MapTile[] tiles) {
    for(int i = 0; i < tiles.length; i++){
      if(tiles[i].x < dimensions[0]) {
        dimensions[0] = tiles[i].x;
      }
      if(tiles[i].x > dimensions[2]) {
        dimensions[2] = tiles[i].x;
      }
      if(tiles[i].y < dimensions[1]) {
        dimensions[1] = tiles[i].y;
      }
      if(tiles[i].y > dimensions[3]) {
        dimensions[3] = tiles[i].y;
      }
      
      if(!map.containsKey(tiles[i].x)){
        map.put(tiles[i].x, new Hashtable<Integer,MapTile>());
      }
      map.get(tiles[i].x).put(tiles[i].y, tiles[i]);
      tiles[i].parentMap=()->{return this;};
    }
    for(int i = dimensions[0]; i <= dimensions[2]; i++) {
      if(map.get(i) == null) {
        map.put(i,new Hashtable<Integer,MapTile>());
      }
      for(int j = dimensions[1]; j <= dimensions[3]; j++) {
        if(map.get(i).get(j) == null) {
          map.get(i).put(j, new MapTile(i, j));
          map.get(i).get(j).parentMap = ()->{return this;};
        }
      }
    }
    return(this);
  }
  
  public Map(MapTile[] tilez) {
    buildMap(tilez);
  }
  public Map(MapTile[] tilez,boolean usetheforceluke){
    this(tilez);
    forceDimensions=usetheforceluke;
  }

  public Map putTile(MapTile tile) {
    if(forceDimensions&&(tile.x<dimensions[0]||tile.x>dimensions[2]||tile.y<dimensions[1]||tile.y>dimensions[3])){
      throw new IllegalArgumentException("Dimensions out of bounds");
    } else {
      if(map.get(tile.x) != null){
        if(map.get(tile.x).get(tile.y)!=null) {
          map.get(tile.x).put(tile.y, tile);
          for(int i = dimensions[0]; i <= dimensions[2]; i++) {
            if(map.get(i) == null) {
              if(forceDimensions&&(i<dimensions[0]||i>dimensions[2])){
                throw new IllegalArgumentException("Dimensions out of bounds");
              } else {
                map.put(i,new Hashtable<Integer,MapTile>());
              }
            }
            for(int j = dimensions[1]; j <= dimensions[3]; j++) {
              
              if(map.get(i).get(j) == null) {
                map.get(i).put(j, new MapTile(i, j));
              }
            }
          }
        } else {
          map.get(tile.x).put(tile.y, tile);
        }
        
      
      } else {
        MapTile[] a = {tile};
        this.buildMap(a);
      }
    }
    return(this);
  }
  public Map putTile(MapTile[] tilez) {
    for(int i = 0; i<tilez.length;i++) {
      putTile(tilez[i]);
    }
    return(this);
  }
  
  public String Stringify() {
    String out = "";
    for(int i = dimensions[3]; i >= dimensions[1]; i--){
      for(int j = dimensions[0]; j<= dimensions[2]; j++) {
        out += map.get(j).get(i).character();
      }
      out += "\n";
    }
    return(out);
  }
  public String Stringify(int x, int y,int width, int height) {
    String out = "";
    double heightToRender = (height+0.5)/2;
    double widthToRender = (width+0.5)/2-0.5;
    for(int i = x+(int)heightToRender;i>=x-heightToRender;i--) {
      for(int j = y-(int)widthToRender;j<=y+widthToRender+1;j++) {
        if(map.containsKey(i)) {
          if(map.get(i).containsKey(j)){
            out += map.get(i).get(j).character();
          } else {
            out += ".";
          }
        } else {
          out += ".";
        }
      }  
      out += "\n";
    }
    return(out);
  }
}