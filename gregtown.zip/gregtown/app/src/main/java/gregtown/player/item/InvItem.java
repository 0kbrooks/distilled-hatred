package gregtown.player.item;
public class InvItem {
  String name = "item";
  char icon = '&';
  String description = "description";
  public InvItem(String n, char i, String d) {
    name=n;
    icon=i;
    description=d;
  }
  public InvItem(String n, String d) {
    //this(n,"&",d)
  }
}