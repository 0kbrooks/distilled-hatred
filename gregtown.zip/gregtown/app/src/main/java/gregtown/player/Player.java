package gregtown.player;
import gregtown.player.item.*;
import java.util.Hashtable;

public class Player {
  int x = 0;
  int y = 0;
  Hashtable<String,InvItem> Inventory = new Hashtable<String,InvItem>();
  public Player() {
    
  }
}