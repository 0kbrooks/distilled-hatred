package gregtown.player.command;

import java.util.function.Function;
import java.lang.IndexOutOfBoundsException;

//import java.util.Stack;
import java.util.Hashtable;

public class Command {
  public static Hashtable<Command,Integer> commandsStack;
  public static Hashtable<String,Integer> aliasesTable;
  private String name;
  private String[] aliases;
  private Function<String[],Void> func;
  static {
    commandsStack = new Hashtable<Command,Integer>();
    aliasesTable = new Hashtable<String,Integer>();
  }
  public Command(String p,String[] pp, Function<String[],Void> ppp) {
    name=p;
    aliases=pp;
    func=ppp;
    commandsStack.put(this,commandsStack.size());
    for(String i:pp) {
      aliasesTable.put(i,commandsStack.size()-1);
    }
  }
  public Command(String p,Function<String[],Void> pp) {
    this(p,new String[0],pp);
  }
  public static void call(String name, String[] args) {
    try{
      System.out.println(commandsStack.get(aliasesTable.get(name)));
    } catch(IndexOutOfBoundsException e) {}
  }
  public void call(String[] args) {
    func.apply(args);
  }
}