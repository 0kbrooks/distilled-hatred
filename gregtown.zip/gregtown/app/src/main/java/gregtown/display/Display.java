package gregtown.display;

import java.util.Hashtable;
import java.lang.IllegalArgumentException;

public class Display {
  private Hashtable<Integer, DisplayWindow> windows = new Hashtable<Integer, DisplayWindow>();
  private int selectedWindow = 0;
  public int selectedWindow() {
    return selectedWindow;
  }
  public Hashtable<Integer, DisplayWindow> windows() {
    return windows;
  }
  public Display(DisplayWindow[] windowz) {
    if (windowz.length > 4) {
      throw new IllegalArgumentException("Too many windows!");
    } else {
      for (int i = 0; i < windowz.length; i++) {
        windows.put(i, windowz[i]);
      }
    }
  }

  public Display(DisplayWindow[] windowz, int selectdWin) {
    this(windowz);
    if (selectdWin > 3) {
      throw new IllegalArgumentException("Selected window out of bounds!");
    }
    selectedWindow = selectdWin;
  }

  public String Stringify() {
    int l = 0;
    int h = 0;
    String out = "";
    if (windows.size() == 3) {
    }
    if (windows.size() == 2) {
      if (windows.get(0).length > windows.get(1).length) {
        l = windows.get(0).length;
        windows.get(1).length = l;
      } else {
        l = windows.get(0).length;
        windows.get(1).length = l;
      }
      /*if (windows.get(1).length != l && windows.get(1).lockDimensions) {
        // throw new IllegalArgumentException("Window length mismatch!");
      } else if (windows.get(0).lockDimensions) {
        // throw new IllegalArgumentException("Window length mismatcwinh!");
      }*/
      h = windows.get(0).height + windows.get(1).height;
      if (windows.size() > 1) {
        h += 1;
      }
      l += 2;
      h += 2;
    }
    if (windows.size() == 3) {
      windows.get(2).length = windows.get(0).length + windows.get(1).length;
    }
    if (windows.size() == 4) {
      if (windows.get(0).length > windows.get(2).length) {
        windows.get(2).length = windows.get(0).length;
      } else {
        windows.get(0).length = windows.get(2).length;
      }
      if (windows.get(1).length > windows.get(3).length) {
        windows.get(3).length = windows.get(1).length;
      } else {
        windows.get(1).length = windows.get(3).length;
      }
      if (windows.get(2).height > windows.get(3).height) {
        windows.get(3).height = windows.get(2).height;
      } else {
        windows.get(2).height = windows.get(3).height;
      }
    }
    if(windows.get(0).height>windows.get(1).height) {
      windows.get(1).height=windows.get(0).height;
    } else {
      windows.get(0).height=windows.get(1).height;
    }
    out += "+";
    for (int i = 0; i < windows.get(0).length; i++) {
      if (selectedWindow == 0) {
        out += "=";
      } else {
        out += "-";
      }
    }
    out += "+";
    if (windows.size() > 2) {
      for (int i = 0; i < windows.get(1).length; i++) {
        if (selectedWindow == 1) {
          out += "=";
        } else {
          out += "-";
        }
      }
      out += "+";
    }
    out += "\n";
    String[] win0strings = windows.get(0).getStrings();
    String[] win1strings = { "" };
    String[] win2strings = { "" };
    String[] win3strings = { "" };
    if (windows.size() > 1) {
      win1strings = windows.get(1).getStrings();
    }
    if (windows.size() > 2) {
      win2strings = windows.get(2).getStrings();
    }
    if (windows.size() > 3) {
      win3strings = windows.get(3).getStrings();
    }
    for (int i = 0; i < windows.get(0).height; i++) {
      if (selectedWindow == 0) {
        out += "‖";
      } else {
        out += "|";
      }
      try {
        out += win0strings[i];
      } catch (ArrayIndexOutOfBoundsException e) {

      }
      ;
      if (windows.size() > 2) {
        if (selectedWindow == 0 || selectedWindow == 1) {
          out += "‖";
        } else {
          out += "|";
        }
        try {
          if (windows.size() > 1) {
            out += win1strings[i];
          }
        } catch (ArrayIndexOutOfBoundsException e) {

        }
        ;
        if (selectedWindow == 1) {
          out += "‖";
        } else {
          out += "|";
        }
      } else if (selectedWindow == 0) {
        out += "‖";
      } else {
        out += "|";
      }
      out += "\n";
    }
    out += "+";
    for (int i = 0; i < windows.get(0).length; i++) {
      if (selectedWindow == 0) {
        out += "=";
      } else {
        if (windows.size() == 2) {
          out += "=";
        } else if (windows.size() >= 3 && selectedWindow == 2) {
          out += "=";
        } else {
          out += "-";
        }
      }
    }
    out += "+";
    if (windows.size() == 2) {
      out += "\n";
      for (int i = 0; i < windows.get(1).height; i++) {
        if (selectedWindow == 1) {
          out += "‖";
        } else {
          out += "|";
        }
        out += win1strings[i];
        if (selectedWindow == 1) {
          out += "‖\n";
        } else {
          out += "|\n";
        }
      }
      out += "+";
      for (int i = 0; i < windows.get(0).length; i++) {
        if (selectedWindow == 1) {
          out += "=";
        } else {
          out += "-";
        }
      }
      out += "+";
    }
    if (windows.size() > 2) {
      for (int i = 0; i < windows.get(1).length; i++) {
        if (selectedWindow == 1 || selectedWindow == 3) {
          out += "=";
        } else if (windows.size() == 3 && selectedWindow == 2) {
          out += "=";
        } else {
          out += "-";
        }
      }
      out += "+";
    }
    if (windows.size() == 3) {
      out += "\n";
      for (int i = 0; i < windows.get(2).height; i++) {
        if (selectedWindow == 2) {
          out += "‖" + win2strings[i] + "‖\n";
        } else {
          out += "|" + win2strings[i] + "|\n";
        }
      }
      out += "+";
      for (int i = 0; i < windows.get(2).length; i++) {
        if (selectedWindow == 2) {
          out += "=";
        } else {
          out += "-";
        }
      }
      out += "+";
    }
    if (windows.size() == 4) {
      out += "\n";
      for (int i = 0; i < windows.get(2).height; i++) {
        if (selectedWindow == 2) {
          out += "‖";
        } else {
          out += "|";
        }
        out += win2strings[i];
        if (selectedWindow == 2 || selectedWindow == 3) {
          out += "‖";
        } else {
          out += "|";
        }
        out += win3strings[i];
        if (selectedWindow == 3) {
          out += "‖\n";
        } else {
          out += "|\n";
        }
      }
      out += "+";
      for (int i = 0; i < windows.get(2).length; i++) {
        if (selectedWindow == 2) {
          out += "=";
        } else {
          out += "-";
        }
      }
      out += "+";
      for (int i = 0; i < windows.get(3).length; i++) {
        if (selectedWindow == 3) {
          out += "=";
        } else {
          out += "-";
        }
      }
      out += "+";
    }
    return (out);
  }
}