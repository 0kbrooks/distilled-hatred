package gregtown.display;
import gregtown.map.*;
public class MapDisplayWindow extends DisplayWindow {
  Map map;
  public MapDisplayWindow(int l,int h) {
    super(l,h,"");
  }
  @Override public String[] getStrings() {
    String[] out = {""};
    String thingy = map.Stringify(0,0,length,height);
    for(int i = 0;i<thingy.length();i++){
      if(thingy.charAt(i)=='\n'){
        thingy = thingy.substring(0,i)+thingy.substring(0, i+1);
      }
    }
    return(out);
  }
}