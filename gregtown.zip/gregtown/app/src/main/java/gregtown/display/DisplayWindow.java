package gregtown.display;

import java.lang.StringIndexOutOfBoundsException;
import java.util.Arrays;
import gregtown.map.*;

public class DisplayWindow {
  protected int length;
  protected int height;
  protected Object content;
  protected boolean lockDimensions;
  public int xOffset;
  public int yOffset;

  public DisplayWindow(int l,int h, String c) {
    length=l;
    height=h;
    content=c;
  }  
  public DisplayWindow(int l,int h, Map c) {
    length=l;
    height=h;
    content=c;
  }
  public DisplayWindow(int l, int h, String c, boolean lock) {
    this(l,h,c);
    lockDimensions=lock;
  }
  public DisplayWindow(int l, int h, Map c, boolean lock) {
    this(l,h,c);
    lockDimensions=lock;
  }
  public String[] getStrings() {
    String[] out = new String[height];
    if(content instanceof Map){
      out = ((Map)content).Stringify(xOffset,yOffset,length,height).split("\n");
    }else if (content instanceof String){
      for(int i = 0;i<out.length;i++){
        try{
          out[i]=((String)content).substring(i*length,(i+1)*length);
        } catch(StringIndexOutOfBoundsException e) {
          try{
            out[i]=((String)content).substring(i*length,((String)content).length());
          } catch(StringIndexOutOfBoundsException ee) {
            
          }
        }
      }
    }
    for(int i = 0;i<out.length;i++){
      if(out[i]==null){
        char[] j = new char[length];
        Arrays.fill(j,'.');
        out[i]=new String(j);
      } else if(out[i].length()<length) {
        int l = out[i].length();
        for(int k = length;k>l;k--) {
          out[i]+=".";
        }
      }
    }
    /*for(String l:out) {
      int k = l.length();
      if(k>length) {
        for(int j = 0;j<length-k;j++) {
          l+=" ";
        }
      }
    }*/
    return(out);
  }
}