package gregtown;

import java.util.Scanner;
import gregtown.display.*;
import gregtown.map.*;
//import gregtown.player.command.*;
//import java.util.Stack;

public class Main {
  public static final Scanner scanner = new Scanner(System.in);

  public static void main(String[] args) {
    Map thing = new Map(new RegionMapTile[] {new RegionMapTile(0,0)});
    DisplayWindow greg = new DisplayWindow(4, 5, thing);
    DisplayWindow greg1 = new DisplayWindow(8, 3, ((RegionMapTile)thing.map().get(0).get(0)).submap());
    DisplayWindow greg2 = new DisplayWindow(12, 3, "blah blah blah blah blah blah");
    DisplayWindow greg3 = new DisplayWindow(4, 3, "window content");
    Display greg7 = new Display(new DisplayWindow[] { greg, greg1, greg2, greg3 }, 3);
    String gotopenistown = greg7.Stringify();
    System.out.println(gotopenistown);
    String in;
    while (!(in = scanner.nextLine()).equals("exit")) {
      if (in.equals("east")) {
        // System.out.print(greg.xOffset + "->");
        greg.xOffset += 1;
        // System.out.println(greg.xOffset);
      } else if (in.equals("west")) {
        // System.out.print(greg.xOffset + "->");
        greg.xOffset -= 1;
        // System.out.println(greg.xOffset);
      } else if (in.equals("north")) {
        // System.out.print(greg.yOffset + "->");
        greg.yOffset += 1;
        // System.out.println(greg.yOffset);
      } else if (in.equals("south")) {
        // System.out.print(greg.yOffset + "->");
        greg.yOffset -= 1;
        // System.out.println(greg.yOffset);
      } else {
        send(in);
      }
      gotopenistown = greg7.Stringify();
      System.out.println(gotopenistown);
    }
    {
      System.out.println("shut the fuck up lsoer");
    }
  }
  private static void send(String in) {
    String[] tokens = in.split("\\s+");
    for(String i: tokens) {
      //System.out.print(i+"/");
    }
    //System.out.println();
  }
}